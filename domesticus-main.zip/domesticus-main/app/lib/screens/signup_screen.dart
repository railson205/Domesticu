import 'package:app/helpers/validators.dart';
import 'package:flutter/material.dart';
import 'package:app/model/user_manager.dart';
import 'package:provider/provider.dart';
import 'package:app/model/users.dart';

class SignUpScreen extends StatelessWidget {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  final User user = User();

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: BackButton(color: primaryColor),
        centerTitle: true,
        title: Text(
          'Cadastro',
          style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Form(
            //TODO: form
            key: formKey,
            child: Consumer<UserManager>(builder: (_, userManager, __) {
              return ListView(
                padding: EdgeInsets.symmetric(horizontal: 25),
                children: <Widget>[
                  Divider(
                    color: Colors.white,
                    height: 20,
                  ),
                  TextFormField(
                    //TODO: nome
                    enabled: !userManager.loading,
                    decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.person,
                          size: 20,
                          color: primaryColor,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        labelText: 'Nome Comleto'),
                    validator: (name) {
                      if (name.isEmpty)
                        return 'Campo Obrigatório';
                      else if (name.trim().split(' ').length <= 1)
                        return 'Preencha seu Nome completo';
                      return null;
                    },
                    onSaved: (name) => user.name = name,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: TextFormField(
                      //TODO: email
                      enabled: !userManager.loading,
                      decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.alternate_email,
                            size: 20,
                            color: primaryColor,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          labelText: 'E-mail'),
                      keyboardType: TextInputType.emailAddress,
                      validator: (email) {
                        if (email.isEmpty)
                          return 'Campo Obrigatório';
                        else if (!emailValidate(email))
                          return 'E-mail inválido';
                        return null;
                      },
                      onSaved: (email) => user.email = email,
                    ),
                  ),
                  TextFormField(
                    //TODO: senha
                    enabled: !userManager.loading,
                    decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.lock,
                          size: 20,
                          color: primaryColor,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        labelText: 'Senha'),
                    obscureText: true,
                    validator: (password) {
                      if (password.isEmpty)
                        return 'Campo Obrigatório';
                      else if (password.length < 6)
                        return 'Mínimo 6 caracteres';
                      return null;
                    },
                    onSaved: (password) => user.password = password,
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10, bottom: 100),
                    child: TextFormField(
                      //TODO: Repetir a senha
                      enabled: !userManager.loading,
                      decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.lock,
                            size: 20,
                            color: primaryColor,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          labelText: 'Repita a senha'),
                      obscureText: true,
                      validator: (pass) {
                        if (pass.isEmpty)
                          return 'Campo Obrigatório';
                        else if (pass.length < 6) return 'Mínimo 6 caracteres';
                        return null;
                      },
                      onSaved: (pass) => user.confirmPassword = pass,
                    ),
                  ),
                  // ignore: deprecated_member_use
                  RaisedButton(
                    //TODO: cadastrar
                    disabledColor: Color.fromRGBO(74, 64, 168, 100),
                    padding: EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    //TODO: texto - cadastrar
                    child: userManager.loading
                        ? CircularProgressIndicator()
                        : const Text(
                            'Cadastrar',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 25,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                    color: primaryColor,
                    //TODO: onPressed - Cadastrar
                    onPressed: userManager.loading
                        ? null
                        : () {
                            if (formKey.currentState.validate()) {
                              formKey.currentState.save();
                              if (user.password != user.confirmPassword) {
                                scaffoldKey.currentState
                                    // ignore: deprecated_member_use
                                    .showSnackBar(SnackBar(
                                  content: Text('Senhas não coincidem'),
                                  backgroundColor: Colors.blue,
                                ));
                                return;
                              }
                              userManager.signUp(
                                  user: user,
                                  onSucess: () {
                                    Navigator.of(context).pop();
                                  },
                                  onFail: (e) {
                                    scaffoldKey.currentState
                                        // ignore: deprecated_member_use
                                        .showSnackBar(SnackBar(
                                      content: Text('Falha ao cadastrar: $e'),
                                      backgroundColor: Colors.blue,
                                    ));
                                  });
                            }
                          },
                  ),
                ],
              );
            })),
      ),
    );
  }
}
