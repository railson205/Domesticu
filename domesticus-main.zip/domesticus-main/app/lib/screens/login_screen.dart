import 'package:app/helpers/validators.dart';
import 'package:app/model/user_manager.dart';
import 'package:app/model/users.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
        key: scaffoldKey,
        appBar: AppBar(
          //TODO: appbar
          centerTitle: true,
          title: Text(
            'Login',
            style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold),
          ),
          leading: BackButton(color: primaryColor),
          backgroundColor: Colors.white,
        ),
        body: Center(
            child: ListView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          children: <Widget>[
            Form(
              key: formKey,
              child: Consumer<UserManager>(
                builder: (_, userManager, __) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.topCenter,
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: TextFormField(
                          //TODO: email
                          enabled: !userManager.loading,
                          controller: emailController,
                          autocorrect: false,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                            ),
                            labelText: 'Email',
                            prefixIcon: Icon(
                              Icons.alternate_email,
                              size: 20,
                            ),
                          ),
                          validator: (email) {
                            if (!emailValidate(email)) return 'E-mail inválido';
                            return null;
                          },
                        ),
                      ),
                      TextFormField(
                        //TODO: senha
                        enabled: !userManager.loading,
                        controller: passController,
                        autocorrect: false,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          labelText: 'Senha',
                          prefixIcon: Icon(
                            Icons.lock,
                            size: 20,
                          ),
                        ),
                        obscureText: true,
                        validator: (pass) {
                          if (pass.isEmpty || pass.length < 6)
                            return 'Mínimo 6 caracteres.';
                          return null;
                        },
                      ),
                      Divider(
                        color: Colors.white,
                        height: 10.0,
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        // ignore: deprecated_member_use
                        child: FlatButton(
                          //TODO: esqueceu a senha
                          padding: EdgeInsets.zero,
                          onPressed: () {
                            Navigator.of(context)
                                .pushReplacementNamed('/recoverpass');
                          },
                          child: Text(
                            'Esqueceu a senha?',
                            style: TextStyle(
                              color: primaryColor,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                      Divider(
                        color: Colors.white,
                        height: 20.0,
                      ),
                      // ignore: deprecated_member_use
                      RaisedButton(
                        //TODO:entrar
                        disabledColor: Color.fromRGBO(74, 64, 168, 100),
                        padding: EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                        ),

                        color: primaryColor,
                        onPressed: userManager.loading
                            ? null
                            : () {
                                if (formKey.currentState.validate()) {
                                  userManager.signIn(
                                      user: User(
                                          email: emailController.text,
                                          password: passController.text),
                                      onFail: (e) {
                                        scaffoldKey.currentState
                                            // ignore: deprecated_member_use
                                            .showSnackBar(SnackBar(
                                          content: Text('Falha ao entrar: $e'),
                                          backgroundColor: Colors.blue,
                                        ));
                                      },
                                      onSucess: () {
                                        Navigator.of(context).pop();
                                      });
                                }
                              },

                        child: userManager.loading
                            ? CircularProgressIndicator()
                            : const Text(
                                'Entrar',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Text(
                          'ou',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            color: primaryColor,
                          ),
                        ),
                      ),
                      // ignore: deprecated_member_use
                      FlatButton(
                        //TODO:continue com o google
                        minWidth: 260,
                        height: 60,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: primaryColor)),
                        onPressed: () {},
                        child: Text(
                          'Continue com Google',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.w800,
                            color: primaryColor,
                          ),
                        ),
                      ),
                      Divider(
                        height: 200,
                        color: Colors.white,
                      ),
                      Text(
                        'Não tem uma conta?',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w400,
                          color: primaryColor,
                        ),
                      ),
                      // ignore: deprecated_member_use
                      FlatButton(
                        //TODO:cadastro
                        onPressed: () {
                          Navigator.of(context).pushReplacementNamed('/signup');
                        },
                        child: Text(
                          ' Cadastre-se',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.w800,
                            color: primaryColor,
                          ),
                        ),
                      )
                    ],
                  );
                },
              ),
            ),
          ],
        )));
  }
}
