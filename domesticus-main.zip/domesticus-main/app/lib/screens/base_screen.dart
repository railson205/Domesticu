import 'package:app/custom_drawer/custom_drawer.dart';
import 'package:app/custom_drawer/custom_drawer_header.dart';
// ignore: unused_import
import 'package:app/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:app/model/page_manager.dart';
// ignore: unused_import
import 'signup_screen.dart';

class BaseScreen extends StatelessWidget {
  final PageController pageController = PageController();

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;

    return Provider(
      create: (_) => PageManager(pageController),
      child: PageView(
        controller: pageController,
        physics: const NeverScrollableScrollPhysics(),
        children: <Widget>[
          Scaffold(
            drawer: CustomDrawer(),
            appBar: AppBar(
              title: Text('Home'),
              backgroundColor: primaryColor,
            ),
          ),
          Scaffold(
            drawer: CustomDrawer(),
            appBar: AppBar(
              title: Text('Home2'),
              backgroundColor: primaryColor,
            ),
          ),
          Scaffold(
            drawer: CustomDrawer(),
            appBar: AppBar(
              title: Text('Home3'),
              backgroundColor: primaryColor,
            ),
          ),
          Scaffold(
            drawer: CustomDrawer(),
            appBar: AppBar(
              title: Text('Home4'),
              backgroundColor: primaryColor,
            ),
          ),
        ],
      ),
    );
  }
}
