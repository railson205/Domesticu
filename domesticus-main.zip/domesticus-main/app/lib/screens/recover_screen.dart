import 'package:app/model/user_manager.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:app/helpers/validators.dart';
import 'package:app/model/users.dart';

class RecoverScreen extends StatelessWidget {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
      key: scaffoldKey,
      //backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Recuperar a senha',
          style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold),
        ),
        leading: BackButton(color: primaryColor),
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: ListView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          shrinkWrap: true,
          children: <Widget>[
            Form(
                key: formKey,
                child: Consumer<UserManager>(builder: (_, userManager, __) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Text(
                        'Digite o Email cadastrado:',
                        //textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w400,
                          color: primaryColor,
                        ),
                      ),
                      Divider(
                        color: Colors.white,
                        height: 10,
                      ),
                      TextFormField(
                        //TODO: Recuperar senha/email

                        enabled: !userManager.loading,
                        controller: emailController,
                        autocorrect: false,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          labelText: 'Email',
                          prefixIcon: Icon(
                            Icons.alternate_email,
                            size: 20,
                          ),
                        ),
                        validator: (email) {
                          if (!emailValidate(email)) return 'E-mail inválido';
                          return null;
                        },
                      ),
                      Divider(
                        color: Colors.white,
                        height: 50,
                      ),
                      Divider(height: 20, color: Colors.white),
                      RaisedButton(
                        padding: EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                        ),
                        color: primaryColor,
                        onPressed: userManager.loading
                            ? null
                            : () {
                                if (formKey.currentState.validate())
                                  userManager.recoverPass(
                                    user: User(email: emailController.text),
                                    onSucess: () {
                                      scaffoldKey.currentState
                                          // ignore: deprecated_member_use
                                          .showSnackBar(SnackBar(
                                        content: Text('Verifique seu Email'),
                                        backgroundColor: Colors.blue,
                                      ));
                                    },
                                  );
                              },
                        child: Text(
                          'Enviar',
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      )
                    ],
                  );
                }))
          ],
        ),
      ),
    );
  }
}
