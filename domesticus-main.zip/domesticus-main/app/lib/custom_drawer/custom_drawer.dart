import 'package:app/custom_drawer/custom_drawer_header.dart';
import 'package:app/custom_drawer/drawer_tile.dart';
import 'package:flutter/material.dart';

class CustomDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
      children: <Widget>[
        CustomDrawerHeader(),
        DrawerTile(iconData: Icons.home, title: 'titulo 0', page: 0),
        DrawerTile(iconData: Icons.list, title: 'titulo 1', page: 1),
        DrawerTile(
            iconData: Icons.playlist_add_check, title: 'titulo 2', page: 2),
        DrawerTile(iconData: Icons.location_on, title: 'titulo 3', page: 3),
      ],
    ));
  }
}
