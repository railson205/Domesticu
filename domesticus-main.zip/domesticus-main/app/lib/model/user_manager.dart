import 'package:app/model/users.dart';
import 'package:app/helpers/firebase_errors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';

class UserManager extends ChangeNotifier {
  UserManager() {
    _loadCurrentUser();
  }

  bool get isLoggedIn => user != null;

  bool _loading = false;

  bool get loading => _loading;

  final FirebaseAuth auth = FirebaseAuth.instance;
  final Firestore firestore = Firestore.instance;

  User user;
//TODO: sign in
  Future<void> signIn({User user, Function onFail, Function onSucess}) async {
    loading = true;
    try {
      // ignore: unused_local_variable
      final AuthResult result = await auth.signInWithEmailAndPassword(
          email: user.email, password: user.password);

      await _loadCurrentUser(firebaseUser: result.user);

      onSucess();
    } on PlatformException catch (e) {
      onFail(getErrorString(e.code));
    }

    loading = false;
  }

//TODO: sign up
  Future<void> signUp({User user, Function onFail, Function onSucess}) async {
    loading = true;

    try {
      // ignore: unused_local_variable
      final AuthResult result = await auth.createUserWithEmailAndPassword(
          email: user.email, password: user.password);

      user.id = result.user.uid;
      this.user = user;

      await user.saveData();

      onSucess();
    } on PlatformException catch (e) {
      onFail(getErrorString(e.code));
    }
    loading = false;
  }

//TODO: sign out
  void signOut() {
    auth.signOut();
    user = null;
    notifyListeners();
  }

  set loading(bool value) {
    _loading = value;
    notifyListeners();
  }

//TODO: recuperar a senha
  void recoverPass({User user, Function onSucess}) {
    auth.sendPasswordResetEmail(email: user.email);
    onSucess();
  }

//TODO: usuario atual
  Future<void> _loadCurrentUser({FirebaseUser firebaseUser}) async {
    final FirebaseUser currentUser = firebaseUser ?? await auth.currentUser();

    if (currentUser != null) {
      final DocumentSnapshot docUser =
          await firestore.collection('users').document(currentUser.uid).get();

      user = User.fromDocument(docUser);
      print(user.name);

      notifyListeners();
    }
  }
}
